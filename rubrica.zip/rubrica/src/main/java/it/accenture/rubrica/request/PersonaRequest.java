package it.accenture.rubrica.request;

import java.util.List;

public class PersonaRequest {

	private Long id;
	private String nome;
	private String cognome;
	private List<String>emailList;
	private List<String>numeri;
	
	
	public PersonaRequest() {
	}


	public PersonaRequest(Long id, String nome, String cognome, List<String> emailList, List<String> numeri) {
		super();
		this.id = id;
		this.nome = nome;
		this.cognome = cognome;
		this.emailList = emailList;
		this.numeri = numeri;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getCognome() {
		return cognome;
	}


	public void setCognome(String cognome) {
		this.cognome = cognome;
	}


	public List<String> getEmailList() {
		return emailList;
	}


	public void setEmailList(List<String> emailList) {
		this.emailList = emailList;
	}


	public List<String> getNumeri() {
		return numeri;
	}


	public void setNumeri(List<String> numeri) {
		this.numeri = numeri;
	}


}