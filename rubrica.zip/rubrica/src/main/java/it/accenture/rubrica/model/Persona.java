package it.accenture.rubrica.model;


import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;



@Entity
@Table(name="persona")
public class Persona {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	@Column(name="nome")
	private String nome;
	
	@Column(name="cognome")
	private String cognome;
	
	@OneToMany(mappedBy= "persona", cascade=CascadeType.ALL)
	private List<Email>emailList;
	
	@OneToMany(mappedBy= "persona", cascade=CascadeType.ALL)
	private List<Numero>numeri;

	public Persona() {
	}

	public Persona(Long id, String nome, String cognome, List<Email> emailList, List<Numero> numeri) {
		this.id = id;
		this.nome = nome;
		this.cognome = cognome;
		this.emailList = emailList;
		this.numeri = numeri;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public List<Email> getEmailList() {
		return emailList;
	}

	public void setEmailList(List<Email> emailList) {
		this.emailList = emailList;
	}

	public List<Numero> getNumeri() {
		return numeri;
	}

	public void setNumeri(List<Numero> numeri) {
		this.numeri = numeri;
	}
	
	
	
	
	
	
	
	

}
