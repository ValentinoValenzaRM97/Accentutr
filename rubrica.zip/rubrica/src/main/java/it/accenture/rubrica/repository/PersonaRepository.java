package it.accenture.rubrica.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import it.accenture.rubrica.model.Persona;

public interface PersonaRepository extends JpaRepository<Persona, Long> {

@Query("select persona from Persona persona where persona.nome = ?1")
List<Persona> cercaPerNome(String nome);

/*@Query("select persona from Persona persona where persona.cognome = ?1")
List<Persona> findByCognome(String cognome);*/


}
