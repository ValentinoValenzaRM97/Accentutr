package it.accenture.rubrica.request;

public class NumeroRequest {

	private String numero;
	private Long id_persona;
	
	public NumeroRequest() {
	}

	public NumeroRequest(String numero, Long id_persona) {
		this.numero = numero;
		this.id_persona = id_persona;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public Long getId_persona() {
		return id_persona;
	}

	public void setId_persona(Long id_persona) {
		this.id_persona = id_persona;
	}

	
	
	
}
