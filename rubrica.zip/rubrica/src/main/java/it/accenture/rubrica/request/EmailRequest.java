package it.accenture.rubrica.request;

public class EmailRequest {

	private String email;
	private Long id_persona;
	
	public EmailRequest() {
	}

	public EmailRequest(String email, Long id_persona) {
		this.email = email;
		this.id_persona = id_persona;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getId_persona() {
		return id_persona;
	}

	public void setId_persona(Long id_persona) {
		this.id_persona = id_persona;
	}
	
	
	
	
}
