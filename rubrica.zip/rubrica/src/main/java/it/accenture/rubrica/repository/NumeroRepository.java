package it.accenture.rubrica.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import it.accenture.rubrica.model.Numero;

public interface NumeroRepository extends JpaRepository<Numero, Long> {

}
