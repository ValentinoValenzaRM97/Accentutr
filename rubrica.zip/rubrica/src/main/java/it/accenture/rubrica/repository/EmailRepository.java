package it.accenture.rubrica.repository;

import org.springframework.data.repository.CrudRepository;

import it.accenture.rubrica.model.Email;

public interface EmailRepository extends CrudRepository<Email, Long> {

}
