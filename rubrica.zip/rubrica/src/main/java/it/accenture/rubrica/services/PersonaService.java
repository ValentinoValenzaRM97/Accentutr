package it.accenture.rubrica.services;

import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.accenture.rubrica.model.Email;
import it.accenture.rubrica.model.Numero;
import it.accenture.rubrica.model.Persona;
import it.accenture.rubrica.repository.PersonaRepository;
import it.accenture.rubrica.request.PersonaRequest;

@Service
public class PersonaService {

	@Autowired
	PersonaRepository pr;

	public List<PersonaRequest> trovaListaPersone(){
		List<Persona> persone = pr.findAll();
		List<PersonaRequest> personList = new ArrayList<PersonaRequest>();
		for(Persona persona: persone) {
			PersonaRequest prq=new PersonaRequest();
			prq.setId(persona.getId());
			prq.setNome(persona.getNome());
			prq.setCognome(persona.getCognome());
			prq.setEmailList(createEmailListRequest(persona.getEmailList()));
			prq.setNumeri(createNumeriRequest(persona.getNumeri()));
			personList.add(prq);
		}            
		return personList;
	}

	public Persona inserisciPersona(PersonaRequest prq) {
		Persona persona = new Persona();
		persona.setNome(prq.getNome());
		persona.setCognome(prq.getCognome());
		persona.setEmailList(createEmailList(persona,prq.getEmailList()));
		persona.setNumeri(createNumeri(persona, prq.getNumeri()));

		return pr.save(persona);
	}

	public Persona modificaPersona(Long id, PersonaRequest prq) {
		Persona persona= pr.findById(id).get();
		persona.setNome(prq.getNome());
		persona.setCognome(prq.getCognome());
		persona.setEmailList(createEmailList(persona,prq.getEmailList()));
		persona.setNumeri(createNumeri(persona, prq.getNumeri()));
		return pr.save(persona);

	}

	public List<Email> createEmailList(Persona persona, List<String> emailList) {
		List<Email>out = new ArrayList<Email>();
		for(String itm : emailList) {
			Email email = new Email();
			email.setEmail(itm);
			email.setPersona(persona);
			out.add(email);
		}
		return out;

	}

	public List<String> createEmailListRequest(List<Email> emailList) {
		List<String>out = new ArrayList<String>();
		for(Email itm : emailList) {
			out.add(itm.getEmail());
		}
		return out;

	}
	public List<Numero> createNumeri(Persona persona, List<String> numeri) {
		List<Numero>out = new ArrayList<Numero>();
		for(String itm : numeri) {
			Numero numero = new Numero();
			numero.setNumero(itm);
			numero.setPersona(persona);
			out.add(numero);
		}
		return out;

	}

	public List<String> createNumeriRequest(List<Numero> numeri) {
		List<String>out = new ArrayList<String>();
		for(Numero itm : numeri) {
			out.add(itm.getNumero());
		}
		return out;

	}

	public Persona cercaPersona(Long id) {
		if(pr.existsById(id)) {
			Persona persona=pr.findById(id).get();
			return persona;
		}
		return new Persona();
	}

	public void eliminaPersona(Long id) {
		if(pr.existsById(id)) {
			pr.deleteById(id);
		}
	}

	public List<PersonaRequest> cercaPerNome(String nome){
		List<Persona> persone = pr.cercaPerNome(nome);
		List<PersonaRequest> personList = new ArrayList<PersonaRequest>();
		for(Persona persona: persone) {
			PersonaRequest prq=new PersonaRequest();
			prq.setId(persona.getId());
			prq.setNome(persona.getNome());
			prq.setCognome(persona.getCognome());
			prq.setEmailList(createEmailListRequest(persona.getEmailList()));
			prq.setNumeri(createNumeriRequest(persona.getNumeri()));
			personList.add(prq);
		}
		return personList;

	}

	public List<PersonaRequest> cercaPerCognome(String cognome){
		List<Persona> persone = pr.findAll();
		List<PersonaRequest> personList = new ArrayList<PersonaRequest>();
		for(Persona persona: persone) {
			PersonaRequest prq=new PersonaRequest();
			if(persona.getCognome().equals(cognome)) {
				prq.setId(persona.getId());
				prq.setNome(persona.getNome());
				prq.setCognome(persona.getCognome());
				prq.setEmailList(createEmailListRequest(persona.getEmailList()));
				prq.setNumeri(createNumeriRequest(persona.getNumeri()));
				personList.add(prq);
			}
		}
		return personList;

	}
	
	/*public PersonaRequest cercaPerId(Long id){
		Persona persona= pr.findById(id).get();
		PersonaRequest prq=new PersonaRequest();
		prq.setId(persona.getId());
		prq.setNome(persona.getNome());
		prq.setCognome(persona.getCognome());
		prq.setEmailList(createEmailListRequest(persona.getEmailList()));
		prq.setNumeri(createNumeriRequest(persona.getNumeri()));
		return prq;
	}*/




}




