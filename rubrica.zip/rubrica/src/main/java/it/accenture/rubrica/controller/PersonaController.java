package it.accenture.rubrica.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import it.accenture.rubrica.request.PersonaRequest;
import it.accenture.rubrica.services.PersonaService;

@RestController
@RequestMapping("/persona")
public class PersonaController {

	@Autowired
	PersonaService ps;

	@PostMapping("/inserisci")
	public ResponseEntity inserisciPersona(@RequestBody PersonaRequest pr) {
		ps.inserisciPersona(pr);
		return ResponseEntity.ok("persona inserita");
	}

	@PutMapping("/modifica/{id}")
	public ResponseEntity modificaPersona(@RequestBody PersonaRequest pr,@PathVariable(name = "id") Long id) {
		ps.modificaPersona(id, pr);
		return ResponseEntity.ok("persona modificata");
	}

	@DeleteMapping("/elimina/{id}")
	public ResponseEntity eliminaPersona(@PathVariable(name = "id") Long id) {
		ps.eliminaPersona(id);
		return ResponseEntity.ok("Persona eliminata");
	}

	@GetMapping("/listaPersone")
	public List<PersonaRequest> trovaListaPersone() {
		return ps.trovaListaPersone();
	}

	@GetMapping("/cercaPerNome/{nome}")
	public List<PersonaRequest> trovaPersonaPerNome(@PathVariable(name = "nome") String nome){
		return ps.cercaPerNome(nome);
	}
	
	@GetMapping("/cercaPerCognome/{cognome}")
	public List<PersonaRequest> trovaPersonaPerCognome(@PathVariable(name = "cognome") String cognome){
		return ps.cercaPerCognome(cognome);
	}
	
	/*@GetMapping("/cercaPerId/{id}")
	public PersonaRequest trovaPersonaPerId(@PathVariable(name = "id") Long id){
		return ps.cercaPerId(id);
	}
	
	 Logger logger = LoggerFactory.getLogger(PersonaController.class);

	    @RequestMapping("/")
	    public String index() {
	        logger.trace("A TRACE Message");
	        logger.debug("A DEBUG Message");
	        logger.info("An INFO Message");
	        logger.warn("A WARN Message");
	        logger.error("An ERROR Message");

	        return "Howdy! Check out the Logs to see the output...";
	    }*/


}
