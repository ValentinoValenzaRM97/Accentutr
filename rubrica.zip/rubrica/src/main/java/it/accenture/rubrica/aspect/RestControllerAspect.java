package it.accenture.rubrica.aspect;




import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import it.accenture.rubrica.request.PersonaRequest;


@Aspect
@Component
public class RestControllerAspect {
	private static final Logger logger = LoggerFactory.getLogger(RestControllerAspect.class);


	@Before(value="execution(* it.accenture.rubrica.services.PersonaService.*(..)) and args(prq)")
	public void beforeAdvice(JoinPoint joinPoint,PersonaRequest prq) {
		logger.info("before method:" + joinPoint.getSignature());
		logger.info("inserisco una persona");
	}
	@After(value="execution(* it.accenture.rubrica.services.PersonaService.*(..)) and args(prq)")
	public void afterAdvice(JoinPoint joinPoint,PersonaRequest prq) {
		logger.info("after method:" + joinPoint.getSignature());
		logger.info("ho inserito una persona");
	}




}