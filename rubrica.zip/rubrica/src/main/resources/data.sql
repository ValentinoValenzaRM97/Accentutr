/*DROP TABLE IF EXISTS persona;

DROP TABLE IF EXISTS email;

DROP TABLE IF EXISTS numero;

CREATE TABLE `persona` (
  `id` numeric PRIMARY KEY,
  `nome` varchar(255),
  `cognome` varchar(255)
);

CREATE TABLE `email` (
  `id` numeric PRIMARY KEY,
  `email` varchar(255),
  `id_persona` numeric
);

CREATE TABLE `numero` (
  `id` numeric PRIMARY KEY,
  `numero` varchar(255),
  `id_persona` numeric
);

ALTER TABLE `email` ADD FOREIGN KEY (`id_persona`) REFERENCES `persona` (`id`);

ALTER TABLE `numero` ADD FOREIGN KEY (`id_persona`) REFERENCES `persona` (`id`);*/

